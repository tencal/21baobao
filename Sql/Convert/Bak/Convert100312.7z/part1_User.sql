/*------------------------------------------------------------------------------------------------------*/
use [TEUser_Test]  
/*------------------------------------------------------------------------------------------------------*/
SET XACT_ABORT ON 
begin transaction
begin
	truncate table BO_UserHasFunctions
	truncate table BO_UserInGroups
	truncate table BO_UserHasFunGroups
	delete from BO_Users
	
	truncate table BO_UserGroupHasFunGroups
	truncate table BO_GroupHasFunctions
	delete from BO_Groups where LEN(GroupID)<10
	
	truncate table BO_Organizations
	truncate table BO_Positions 
	
	--truncate table BO_AppLog
	--truncate table BO_OperationLog	
end
commit transaction