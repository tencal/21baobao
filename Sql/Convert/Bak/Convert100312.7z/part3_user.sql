/*------------------------------------------------------------------------------------------------------*/
use [TEUser_Test] 
/*------------------------------------------------------------------------------------------------------*/
SET XACT_ABORT ON 
begin transaction
begin
	--Gen_Organizations
	insert into BO_Organizations(Id,
		UnitName,
		UnitCTName,
		Contact_No1,
		Contact_No2,
		Contact_No3,
		Contact_NoType1,
		Contact_NoType2,
		Contact_NoType3,
		Fax,
		CreateBy,
		CreateDate,
		ModifyBy,
		ModifyDate,
		AddressEn,
		AddressCT,
		Gateway,
		Type,
		Status,
		IsBranch,
		Email,
		HandlingEmail
		--,AddressCS,
		--UnitCSName
		)
		select L_Code,	
		L_English,	
		L_Chinese,	
		Contact_No1,
		Contact_No2,	
		Contact_No3,
		Contact_NoType1,	
		Contact_NoType2,
		Contact_NoType3,
		Fax,
		Creator,	
		CreateDate,	
		ModifyBy,	
		ModifyDate,	
		AddressEnglish,	
		AddressChinese,	
		Gateway,
		Type,	
		Status,	
		IsBranch,	
		Email,	
		HandlingEmail	
		from [UAT].dbo.Gen_P_Location
		
    --Gen_Positions  
	insert into BO_Positions(ID,
		PositionName,
		PositionCTName,
		CreateBy,
		CreateDate,
		ModifyBy,
		ModifyDate,
		Status,
		Remark
		)
		select P_Code,
		P_English,
		P_Chinese,
		Creator,
		CreateDate,
		Modify_By,
		ModifyDate,
		Status,
		Remark
		from [UAT].dbo.Gen_Position
	
	--BO_GroupClasses
	update [BO_GroupClasses] set ClassName='Position',ClassCSName=N'ְλ',ClassCTName=N'λ' where ClassID='1'
	if(not exists(select 1 from BO_GroupClasses gc where gc.ClassID='0'))
		insert into [BO_GroupClasses](ClassID,ClassName,ClassCSName,ClassCTName) values('0','Structure',N'����',N'�C��')
	
	--BO_Groups
	insert into BO_Groups(GroupID,
		GroupName,
		GroupCSName,
		ClassID,
		ParentID,
		L_P_Code,
		SortList, --Not null
		GLevel,   --Not null
		IsCatalog,--Not null
		IsBranch  --Not null
		)
		select Id,
		EnglishName,
		ChineseName,
		(case c.division when 'Location' then  '0' else '1' end) as ClassID,
		FatherId,
		L_P_Code,
		'',
		[Class],
		(case c.division when 'Location' then  '1' else '0' end) as IsCatalog,
		'0'
		from [UAT].dbo.CompanyStructure	c
		
	--BO_Users
	INSERT INTO [BO_Users]
           ([UserID]
           ,[UserName]
           ,[ChineseUserName]
           ,[Password]
           ,[Email]
           ,[Gender]
           ,[Birthday]
           ,[Status]  --�����ݿ��ֶ�̫��
           ,[CreateBy]
           ,[CreateDate]
           ,[ModifyBy]
           ,[ModifyDate]
           ,[OrgCode]
           ,[PositionCode],
           InsurLicense,D_InsureAgency_ExpriyDate
           )
    select u.[User_id],u.EnglishName,u.ChineseName,
		u.[Password],u.Email,u.Gender, u.Birthday,u.[Status],u.Creator
		,u.CreateDate,u.ModifyBy,u.ModifyDate, ep.OrgCode,ep.User_PositionCode,u.C_InsureAgencyNo,u.D_InsureAgency_ExpriyDate
    from [UAT].dbo.gen_user u
    left join [UAT].dbo.Employ_Position ep on u.[User_id]=ep.[User_id] 
    --insert test data
    --INSERT INTO [BO_Users]([UserID],[UserName],[Password]) values('f','Front Line','f')
    --INSERT INTO [BO_Users]([UserID],[UserName],[Password]) values('b','Back Office','b')
    --INSERT INTO [BO_Users]([UserID],[UserName],[Password]) values('n','Normal','n')
    --insert into BO_UserInGroups(UserID,GroupID) values('f','200907081740436715')
    --insert into BO_UserInGroups(UserID,GroupID) values('b','200907081741010019')
    
    ----�����û����ڵ�ְλ
    ----delete from BO_UserInGroups
    ----select * from BO_Groups where GroupID in('568','84')
	--insert into BO_UserInGroups(UserID,GroupID)
	--select u.UserID,g.GroupID from [BO_Users] u
	--inner join BO_Groups g on u.PositionCode=g.L_P_Code and g.IsCatalog=0 --ְλ��
	--inner join BO_Groups gg on g.ParentID = gg.GroupID       --ְλ����˾�����
	--inner join BO_Groups ggg on gg.ParentID = ggg.GroupID	 --ְλ�Ļ���
	--inner join BO_Groups gggg on ggg.ParentID = gggg.GroupID	 --ְλ�Ļ���
	--inner join BO_Groups ggggg on gggg.ParentID = ggggg.GroupID	 --ְλ�Ļ���
	--where ((gg.L_P_Code=u.OrgCode and gg.IsCatalog=1) or (ggg.L_P_Code=u.OrgCode and ggg.IsCatalog=1) 
	--	or (gggg.L_P_Code=u.OrgCode and gggg.IsCatalog=1) or(ggggg.L_P_Code=u.OrgCode and ggggg.IsCatalog=1))
	--	and u.UserID='80QI127T'
		
	----091110 
	--declare @userID nvarchar(18)=''
	--declare @orgCode nvarchar(18)=''
	--declare @positionCode nvarchar(18)=''
	--declare @orgCodeGroup nvarchar(18)=''
	--declare @parentGroup nvarchar(18)=''
	--declare @groupID nvarchar(18)=''
	
	--declare cursorUser cursor for 
	--	select u.UserID,u.OrgCode,u.PositionCode from [BO_Users] u --where u.UserID='80QI127T'
	
	--open cursorUser
	--fetch next from cursorUser into @userID,@orgCode,@positionCode
	--while @@fetch_status=0  
	--begin
	--	select @orgCodeGroup=g.GroupID from BO_Groups g where g.L_P_Code=@orgCode and g.IsCatalog=1
	--	set @parentGroup = @orgCodeGroup
	--	while(@groupID='')
	--	begin
	--		select @groupID=g.GroupID from BO_Groups g 
	--		where g.ParentID=@parentGroup and g.L_P_Code=@positionCode and g.IsCatalog=0
			
	--		if(ISNULL(@groupID,'')='')
	--		begin
	--			select @groupID=g.GroupID from BO_Groups g 
	--			where g.ParentID=@parentGroup 
				
	--			if(ISNULL(@groupID,'')<>'')
	--			begin
	--				set @parentGroup=@groupID
	--				set @groupID=''
	--			end
	--			else
	--			begin
	--				break
	--			end
	--		end	
	--		else
	--		begin
	--			print @userID
	--			print @groupID
	--			insert into BO_UserInGroups(UserID,GroupID)
	--			values(@userID,@groupID)
	--			set @groupID=''
	--			break
	--		end
	--	end
		
	--	fetch next from cursorUser into @userID,@orgCode,@positionCode
	--end
	
	--close cursorUser
	--deallocate cursorUser
	
	declare @userID nvarchar(18)=''
	declare @orgCode nvarchar(18)=''
	declare @positionCode nvarchar(18)=''
	declare @groupID nvarchar(18)=''
	
	declare cursorUser cursor for 
		select u.UserID,u.OrgCode,u.PositionCode from [BO_Users] u 
		--where u.UserID in (select UserID from dbo.BO_Users where OrgCode='OLY' and Status='Active')
	
	open cursorUser
	fetch next from cursorUser into @userID,@orgCode,@positionCode
	while @@fetch_status=0  
	begin
		WITH tb(GroupID,L_P_Code,ParentID,IsCatalog)
		AS
		(
			select GroupID,L_P_Code,ParentID,IsCatalog from BO_Groups where L_P_Code=@orgCode
			union all
			SELECT A.GroupID,A.L_P_Code,A.ParentID,A.IsCatalog
			FROM BO_Groups A
			INNER JOIN tb ON A.ParentID = tb.GroupID
		) 

		select @groupID=GroupID from tb where L_P_Code=@positionCode and IsCatalog=0
		
		if(ISNULL(@groupID,'')<>'' and (select COUNT(0) from BO_UserInGroups where UserID=@userID and GroupID=@groupID)=0)
		begin
			print @userID
			print @groupID
			insert into BO_UserInGroups(UserID,GroupID) values(@userID,@groupID)
			set @groupID=''
		end
		
		fetch next from cursorUser into @userID,@orgCode,@positionCode
	end
	
	close cursorUser
	deallocate cursorUser
	

End		
commit transaction